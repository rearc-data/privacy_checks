from .checker import Checker
from .mcprofiler import MCProfiler
PACKAGE_NAME = "privacy_checks"
PACKAGE_VERSION = "0.1"